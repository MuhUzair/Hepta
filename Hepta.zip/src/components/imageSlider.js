import React from 'react';
import Slider from 'react-slick';
import Image1 from "./images/slider-1.jpg.webp";
import Image2 from "./images/slider-2.jpg.webp";
import Image3 from "./images/slider-3.jpg.webp";
import Image4 from "./images/slider-4.jpg.webp";
import Image5 from "./images/slider-5.jpg.webp";
import Image6 from "./images/slider-6.jpg.webp";

const ImageSlider = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    fade: true,
    appendDots: dots => (
      <div
        style={{
          backgroundColor: "transparent",
          paddingBottom: "110px",       
        }}
      >
        <ul style={{margin: "0px" }}> {dots} </ul>
        
      </div>
    ),
  };

  const images = [
    Image1, Image2, Image3, Image4, Image5, Image6
  ];

  return (
    <div>
      <Slider {...settings}>
        {images.map((image, index) => (
          <div key={index}>
            <img src={image} alt={`Slide ${index + 1}`} style={{boxShadow:"0 30px 20px rgba(121, 121, 121, 0.5)" ,width: '70%', marginLeft: "15%" }} />
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default ImageSlider;

import React, { useState, useEffect, useCallback } from "react";
import styles from "./styles/gallery.module.css";
import { Link } from "react-router-dom";
import image from "./images/slider-2.jpg.webp";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
// import breakfastImage from "./images/breakfast.jpg";
// import planetImage from "./images/planetEarth.jpg";
// import planeImage from "./images/airplane.jpg";
// import Beach from "./images/beach.jpg";
// import Mountain from "./images/mountains.jpg";
// import Balloons from "./images/hotAirBalloon.jpg";
// import preImage from "./images/slider-2.jpg.webp" 6 5 sofa climb;
import Image6 from "./images/slider-6.jpg.webp";
import Image5 from "./images/slider-5.jpg.webp";
import Sofa from "./images/sofa.jpg";
import Climb from "./images/climb.jpg";
function Gallery() {
  const [isOpen, setIsOpen] = useState(false);
  const [showHamburger, setShowHamburger] = useState(true);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = useCallback(() => {
    if (isOpen) {
      setIsOpen(false);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleScroll = () => {
      const headerHeight = document.querySelector(
        `.${styles.header}`
      ).offsetHeight;
      if (window.scrollY > headerHeight) {
        setShowHamburger(false);
      } else {
        setShowHamburger(true);
      }
      closeMenu();
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [closeMenu]);

  return (
    <div>
      <div
        className={styles.header}
        style={{ backgroundImage: `url(${image})` }}
      >
        <div className={styles.overlay}></div>
        <div className={styles.content}>
          <h1 className={styles.title}>Hepta</h1>
          <h1 className={styles.heading}>Gallery</h1>
          <p className={styles.description}>
            A free template by{" "}
            <Link to="/" target="_blank" className={styles.link}>
              Colorlib
            </Link>
            . Download and share!
          </p>
        </div>
        {showHamburger && (
          <div className={styles.hamburger} onClick={toggleMenu}>
            ☰
          </div>
        )}
        <div className={`${styles.menu} ${isOpen ? styles.open : ""}`}>
          <Link to="/" className={styles.menuItem}>
            Home
          </Link>
          <Link to="/hotels" className={styles.menuItem}>
            Hotels
          </Link>
          <Link to="/aboutUs" className={styles.menuItem}>
            About Us
          </Link>
          <Link to="/gallery" className={styles.menuItem}>
            Gallery
          </Link>
          <Link to="/news" className={styles.menuItem}>
            News
          </Link>
          <Link to="/Contact" className={styles.menuItem}>
            Contact
          </Link>
        </div>
      </div>

      {/* Third Tab */}

      <div className={styles.thirdTab}>
        {/* Team */}
        <div style={{ backgroundColor: "#fff", height: "170vh" }}>
          {/* Eight Images */}
          <div className={styles.eightImages}>
            {/* Four Images */}
            <div className={styles.fourImages}>
              <div className={styles.imageSix}>
                <img src={Image6} alt="" />
              </div>
              <div className={styles.imageFive}>
                <img src={Image5} alt="" />
              </div>
              <div className={styles.imageSofa}>
                <img src={Sofa} alt="" />
              </div>
              <div className={styles.imageSofa}>
                <img src={Climb} alt="" />
              </div>
            </div>

            {/* Four Images */}
            <div className={styles.fourImagesNext}>
              <div className={styles.imageSofa}>
                <img src={Sofa} alt="" />
              </div>
              <div className={styles.imageSofa}>
                <img src={Climb} alt="" />
              </div>
              <div className={styles.imageSix}>
                <img src={Image6} alt="" />
              </div>
              <div className={styles.imageFive}>
                <img src={Image5} alt="" />
              </div>
            </div>

            {/* Two Images */}
            <div className={styles.twoImages}>
              <div className={styles.imageSixTwo}>
                <img src={Image6} alt="" />
              </div>
              <div className={styles.imageFiveTwo}>
                <img src={Image5} alt="" />
              </div>
            </div>

            {/* Four Images */}
            <div className={styles.fourImagesNext}>
              <div className={styles.imageSofa}>
                <img src={Sofa} alt="" />
              </div>
              <div className={styles.imageSofa}>
                <img src={Climb} alt="" />
              </div>
              <div className={styles.imageSix}>
                <img src={Image6} alt="" />
              </div>
              <div className={styles.imageFive}>
                <img src={Image5} alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}

      <div className={styles.footer}>
        <div className={styles.footerItems}>
          <div className={styles.quickLink}>
            <h3>Quick Link</h3>
            <Link to="/" target="_blank" className={styles.links}>
              About Us
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Terms & Conditions
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Privacy Policy
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Help
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Rooms
            </Link>
          </div>
          <div className={styles.support}>
            <h3>Support</h3>
            <Link to="/" target="_blank" className={styles.links}>
              Our Location
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              The Hosts
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              About
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Contact
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Restaurant
            </Link>
          </div>
          <div className={styles.contactInfo}>
            <h3>ContactInfo</h3>
            <p style={{ color: "#fff" }}>Address:</p>
            <p style={{ marginTop: "1px", fontSize: "21px" }}>
              98 West 21th Street, Suite 721{" "}
            </p>
            <p style={{ marginTop: "1px", fontSize: "21px" }}>
              New York NY 10016
            </p>
            <p style={{ marginTop: "6px", color: "#fff" }}>Phone:</p>
            <p style={{ marginTop: "1px" }}>(+1) 435 3533</p>
            <p style={{ color: "#fff", marginTop: "6px" }}>Email:</p>
            <p style={{ marginTop: "1px" }}>info@yourdomain.com</p>
          </div>
          <div className={styles.subscribe}>
            <h3>Subscribe</h3>
            <p>Sign up for our newsletter</p>
            <input type="email" placeholder="Your Email..." />
          </div>
        </div>
        <hr style={{ border: "0.5px solid #5d5d5db7", width: "82%" }} />
        <div className={styles.footerBottom}>
          <p>
            Copyright © 2024 All rights reserved | This template is made with by{" "}
            <Link to="/" target="_blank" className={styles.btmLink}>
              Colorlib
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
export default Gallery;

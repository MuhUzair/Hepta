import React, { useState, useEffect, useCallback, useRef } from "react";
import styles from "./styles/contact.module.css";
import { Link } from "react-router-dom";
import image from "./images/slider-2.jpg.webp";
import person1 from "./images/person1.jpg";
import person2 from "./images/person2.jpg";
import person3 from "./images/person3.jpg";

function Contact() {
  const [isOpen, setIsOpen] = useState(false);
  const [showHamburger, setShowHamburger] = useState(true);
  const headerRef = useRef(null);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = useCallback(() => {
    setIsOpen(false);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (headerRef.current) {
        const headerHeight = headerRef.current.offsetHeight;
        setShowHamburger(window.scrollY <= headerHeight);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div>
      <div
        className={styles.header}
        style={{ backgroundImage: `url(${image})` }}
        ref={headerRef}
      >
        <div className={styles.overlay}></div>
        <div className={styles.content}>
          <h1 className={styles.title}>Hepta</h1>
          <h1 className={styles.heading}>Contact</h1>
          <p className={styles.description}>
            A free template by{" "}
            <Link to="/" target="_blank" className={styles.link}>
              Colorlib
            </Link>
            . Download and share!
          </p>
        </div>
        {showHamburger && (
          <div className={styles.hamburger} onClick={toggleMenu}>
            ☰
          </div>
        )}
        <div className={`${styles.menu} ${isOpen ? styles.open : ""}`}>
          <Link to="/" className={styles.menuItem} onClick={closeMenu}>
            Home
          </Link>
          <Link to="/hotels" className={styles.menuItem} onClick={closeMenu}>
            Hotels
          </Link>
          <Link to="/aboutUs" className={styles.menuItem} onClick={closeMenu}>
            About Us
          </Link>
          <Link to="/gallery" className={styles.menuItem} onClick={closeMenu}>
            Gallery
          </Link>
          <Link to="/news" className={styles.menuItem} onClick={closeMenu}>
            News
          </Link>
          <Link to="/Contact" className={styles.menuItem} onClick={closeMenu}>
            Contact
          </Link>
        </div>
      </div>

      {/* Third Tab */}
      <div className={styles.thirdTab}>
        <div className={styles.inputDetails}>
          <div className={styles.namePhone}>
            <input type="text" placeholder="Name" />
            <input
              type="text"
              placeholder="Phone"
              style={{ marginLeft: "40px" }}
            />
          </div>
          <input
            type="Email"
            placeholder="Email"
            className={styles.emailInput}
          />
          <textarea name="" id="" placeholder="Write Message"></textarea>
          <button className={styles.watchBtn}>Send Message</button>
        </div>
        <div className={styles.details}>
          <div className={styles.allDetails}>
            <h4
              style={{ marginLeft: "10px", fontSize: "24px", color: "#27a29a" }}
            >
              Address:
            </h4>
            <h1 style={{ fontFamily: " 'Abril Fatface', 'Times', serif", marginLeft: "10px", fontSize: "40px" }}>
              98 West 21th Street, Suite
            </h1>
            <h1 style={{ fontFamily: " 'Abril Fatface', 'Times', serif", marginLeft: "10px", fontSize: "40px" }}>
              721 New York NY 10016
            </h1>
            <h4
              style={{ marginLeft: "10px", fontSize: "24px", color: "#27a29a" }}
            >
              Phone:
            </h4>
            <h1 style={{ fontFamily: " 'Abril Fatface', 'Times', serif", marginLeft: "10px", fontSize: "40px" }}>
              (+1) 435 3533
            </h1>
            <h4
              style={{ marginLeft: "10px", fontSize: "24px", color: "#27a29a" }}
            >
              Email:
            </h4>
            <h1 style={{ fontFamily: " 'Abril Fatface', 'Times', serif", marginLeft: "10px", fontSize: "40px" }}>
              info@yourdomain.com
            </h1>
          </div>
        </div>
      </div>

      {/* Forth Tab*/}
      <div className={styles.forthTab}>
        <h1 style={{marginTop: "50px"}}>Happy Customers</h1>
        <div className={styles.personInfo}>
          <div className={styles.personOne}>
            <img src={person1} alt="" />
            <p>
              “Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts. Separated
              they live in Bookmarksgrove right at the coast of the Semantics, a
              large language ocean.”
            </p>
            <p style={{ marginLeft: "5%", color: "#6c757d" }}>— Clare Gupta</p>
          </div>
          <div className={styles.personTwo}>
            <img src={person2} alt="" />
            <p>
              “Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts. Separated
              they live in Bookmarksgrove right at the coast of the Semantics, a
              large language ocean.”
            </p>
            <p style={{ marginLeft: "5%", color: "#6c757d" }}>— Rogie Slater</p>
          </div>
          <div className={styles.personThree}>
            <img src={person3} alt="" />
            <p>
              “Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts. Separated
              they live in Bookmarksgrove right at the coast of the Semantics, a
              large language ocean.”
            </p>
            <p style={{ marginLeft: "5%", color: "#6c757d" }}>— John Doe</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className={styles.footer}>
        <div className={styles.footerItems}>
          <div className={styles.quickLink}>
            <h3>Quick Link</h3>
            <Link to="/" target="_blank" className={styles.links}>
              About Us
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Terms & Conditions
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Privacy Policy
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Help
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Rooms
            </Link>
          </div>
          <div className={styles.support}>
            <h3>Support</h3>
            <Link to="/" target="_blank" className={styles.links}>
              Our Location
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              The Hosts
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              About
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Contact
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Restaurant
            </Link>
          </div>
          <div className={styles.contactInfo}>
            <h3>Contact Info</h3>
            <p style={{ color: "#fff" }}>Address:</p>
            <p style={{ marginTop: "1px", fontSize: "21px" }}>
              98 West 21th Street, Suite 721{" "}
            </p>
            <p style={{ marginTop: "1px", fontSize: "21px" }}>
              New York NY 10016
            </p>
            <p style={{ marginTop: "6px", color: "#fff" }}>Phone:</p>
            <p style={{ marginTop: "1px" }}>(+1) 435 3533</p>
            <p style={{ color: "#fff", marginTop: "6px" }}>Email:</p>
            <p style={{ marginTop: "1px" }}>info@yourdomain.com</p>
          </div>
          <div className={styles.subscribe}>
            <h3>Subscribe</h3>
            <p>Sign up for our newsletter</p>
            <input type="email" placeholder="Your Email..." />
          </div>
        </div>
        <hr style={{ border: "0.5px solid #5d5d5db7", width: "82%" }} />
        <div className={styles.footerBottom}>
          <p>
            Copyright © 2024 All rights reserved | This template is made with by{" "}
            <Link to="/" target="_blank" className={styles.btmLink}>
              Colorlib
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Contact;

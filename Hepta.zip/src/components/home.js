import React, { useState, useEffect, useCallback } from "react";
import image from "./images/backgroundImage.jpg";
import welcomeImage from "./images/welcome.webp";
import playImage from "./images/play.png";
import styles from "./styles/home.module.css";
import breakfastImage from "./images/breakfast.jpg";
import planetImage from "./images/planetEarth.jpg";
import planeImage from "./images/airplane.jpg";
import Beach from "./images/beach.jpg";
import Mountain from "./images/mountains.jpg";
import Balloons from "./images/hotAirBalloon.jpg";
import { Link } from "react-router-dom";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import ImageSlider from "./imageSlider";
import Image6 from "./images/slider-6.jpg.webp";
import Image5 from "./images/slider-5.jpg.webp";
import Sofa from "./images/sofa.jpg";
import person1 from "./images/person1.jpg";
import person2 from "./images/person2.jpg";
import person3 from "./images/person3.jpg";
import climb from "./images/climb.jpg";
import Star from "./images/star.jpg";

function Home() {
  const [isOpen, setIsOpen] = useState(false);
  const [showHamburger, setShowHamburger] = useState(true);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = useCallback(() => {
    if (isOpen) {
      setIsOpen(false);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleScroll = () => {
      const headerHeight = document.querySelector(
        `.${styles.header}`
      ).offsetHeight;
      if (window.scrollY > headerHeight) {
        setShowHamburger(false);
      } else {
        setShowHamburger(true);
      }
      closeMenu();
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [closeMenu]);
  const scrollToNextDiv = () => {
    const nextDiv = document.getElementById("nextDiv");
    if (nextDiv) {
      nextDiv.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div>
      <div
        className={styles.header}
        style={{ backgroundImage: `url(${image})` }}
      >
        <div className={styles.overlay}></div>
        <div className={styles.content}>
          <h1 className={styles.title}>Hepta</h1>
          <h1 className={styles.heading}>Travels & Tour</h1>
          <p className={styles.description}>
            A free template by{" "}
            <Link to="/" target="_blank" className={styles.link}>
              Colorlib
            </Link>
            . Download and share!
          </p>
          <button
            className={styles.colorlibBtn}
            onClick={() => window.open("http://localhost:3000/", "_blank")}
          >
            Visit Colorlib
          </button>
        </div>
        {showHamburger && (
          <div className={styles.hamburger} onClick={toggleMenu}>
            ☰
          </div>
        )}
        <div className={`${styles.menu} ${isOpen ? styles.open : ""}`}>
          <Link to="/" className={styles.menuItem}>
            Home
          </Link>
          <Link to="/hotels" className={styles.menuItem}>
            Hotels
          </Link>
          <Link to="/aboutUs" className={styles.menuItem}>
            About Us
          </Link>
          <Link to="/gallery" className={styles.menuItem}>
            Gallery
          </Link>
          <Link to="/news" className={styles.menuItem}>
            News
          </Link>
          <Link to="/Contact" className={styles.menuItem}>
            Contact
          </Link>
        </div>
        <div className={styles.arrowDown} onClick={scrollToNextDiv}>
          ↓
        </div>
      </div>

        {/* Welcome to our website*/}
      <div id="nextDiv" className={styles.welcomeBody}>
        <div className={styles.imageStyle}>
          <img src={welcomeImage} alt="" />
        </div>
        <div className={styles.welcomeText}>
          <h1> Welcome To Our Website </h1>
          <p className={styles.farText}>
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts. Separated they
            live in Bookmarksgrove right at the coast of the Semantics, a large
            language ocean.
          </p>
          <p className={styles.farText}>
            A small river named Duden flows by their place and supplies it with
            the necessary regelialia.
          </p>
          <div className={styles.watchVideoBtn}>
            <div>
              <img src={playImage} alt="" className={styles.playImageBtn} />
            </div>
            <div>
              <p className={styles.watchText}>Watch The Video</p>
            </div>
          </div>
        </div>
      </div>
      <hr style={{ border: "1px solid rgba(181, 181, 181, 0.701)" }} />
      <div className={styles.secondTab}>
        <div className={styles.experienceTab}>
          <h1>Experience Once In Your Lifetime</h1>
          <p
            style={{
              width: "44%",
              fontSize: "22px",
              textAlign: "center",
              color: "#6C757D",
            }}
          >
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts. Separated they
            live in Bookmarksgrove right at the coast of the Semantics, a large
            language ocean.
          </p>
        </div>
        {/*Upper Items of Welcome*/}
        <div className={styles.upperItems}>
          <div className={styles.goodFoods}>
            <img src={breakfastImage} alt="" />
            <h2
              style={{
                width: "50%",
                fontFamily: "'Abril Fatface', 'Times', serif",
              }}
            >
              Good Foods
            </h2>
            <p
              style={{
                width: "70%",
                fontSize: "18px",
                textAlign: "center",
                marginLeft: "-80px",
                color: "#6C757D",
              }}
            >
              Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts.
            </p>
          </div>
          <div className={styles.travelAnyWhere}>
            <img src={planetImage} alt="" />
            <h2
              style={{
                marginRight: "60%",
                fontFamily: "'Abril Fatface', 'Times', serif",
              }}
            >
              Travel Anywhere
            </h2>
            <p
              style={{
                width: "70%",
                fontSize: "18px",
                textAlign: "center",
                marginLeft: "-80px",
                color: "#6C757D",
              }}
            >
              Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts.
            </p>
          </div>
          <div className={styles.airplane}>
            <img src={planeImage} alt="" />
            <h2
              style={{
                marginLeft: "10%",
                fontFamily: "'Abril Fatface', 'Times', serif",
              }}
            >
              Airplane
            </h2>
            <p
              style={{
                width: "70%",
                fontSize: "18px",
                textAlign: "center",
                marginLeft: "-80px",
                color: "#6C757D",
              }}
            >
              Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts.
            </p>
          </div>
        </div>
        {/*Lower items of welcome*/}
        <div className={styles.lowerItems}>
          <div className={styles.goodFoods}>
            <img src={Beach} alt="" />
            <h2
              style={{
                width: "50%",
                marginRight: "70%",
                fontSize: "30px",
                fontFamily: "'Abril Fatface', 'Times', serif",
              }}
            >
              Beach Resort
            </h2>
            <p
              style={{
                width: "70%",
                fontSize: "18px",
                textAlign: "center",
                marginLeft: "-80px",
                color: "#6C757D",
              }}
            >
              Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts.
            </p>
          </div>
          <div className={styles.travelAnyWhere}>
            <img src={Mountain} alt="" />
            <h2
              style={{
                marginLeft: "-2%",
                fontFamily: "'Abril Fatface', 'Times', serif",
              }}
            >
              Mountain Climbing
            </h2>
            <p
              style={{
                width: "70%",
                fontSize: "18px",
                textAlign: "center",
                marginLeft: "-80px",
                color: "#6C757D",
              }}
            >
              Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts.
            </p>
          </div>
          <div className={styles.airplane}>
            <img src={Balloons} alt="" />
            <h2
              style={{
                marginRight: "70%",
                fontFamily: "'Abril Fatface', 'Times', serif",
              }}
            >
              Hot Air Balloon
            </h2>
            <p
              style={{
                width: "70%",
                fontSize: "18px",
                textAlign: "center",
                marginLeft: "-80px",
                color: "#6C757D",
              }}
            >
              Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts.
            </p>
          </div>
        </div>
      </div>

        {/*Third Tab*/}
      <div className={styles.thirdTab}>
        <div className={styles.internationalTour}>
          <h1 style={{ width: "50%", textAlign: "center", fontSize: "90px" }}>
            International Tour Management.
          </h1>
        </div>
        <div className={styles.tourPara}>
          <p
            style={{
              width: "50%",
              textAlign: "center",
              fontSize: "25px",
              color: "#6C757D",
            }}
          >
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts. Separated they
            live in Bookmarksgrove right at the coast of the Semantics, a large
            language ocean.
          </p>
        </div>
        <div style={{ backgroundColor: "#65C0BA" }}>
          <ImageSlider />
        </div>

            {/* Recent blog post */}

        <div style={{ backgroundColor: "#65C0BA", height: "157vh" }}>
          <div className={styles.blog}>
            <h1>Recent Blog Post</h1>
          </div>
          <div className={styles.blogPara}>
            <p>
              Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts. Separated
              they live in Bookmarksgrove right at the coast of the Semantics, a
              large language ocean.
            </p>
          </div>
          <div className={styles.threeImages}>
            <div className={styles.imageSix}>
              <img src={Image6} alt="" />
              <p>FEBRUARY 26, 2018</p>
              <h1>45 Best Places To Unwind</h1>
              <p
                style={{
                  marginTop: "18px",
                  color: "#6C757D",
                  fontSize: "24px",
                  width: "80%",
                  lineHeight: "35px",
                  wordSpacing: "15px",
                }}
              >
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts.
              </p>
            </div>
            <div className={styles.imageFive}>
              <img src={Image5} alt="" />
              <p>FEBRUARY 26, 2018</p>
              <h1>45 Best Places To Unwind</h1>
              <p
                style={{
                  marginTop: "18px",
                  color: "#6C757D",
                  fontSize: "24px",
                  width: "80%",
                  lineHeight: "35px",
                  wordSpacing: "15px",
                }}
              >
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts.
              </p>
            </div>
            <div className={styles.imageSofa}>
              <img src={Sofa} alt="" />
              <p>FEBRUARY 26, 2018</p>
              <h1>45 Best Places To Unwind</h1>
              <p
                style={{
                  marginTop: "18px",
                  color: "#6C757D",
                  fontSize: "24px",
                  width: "80%",
                  lineHeight: "35px",
                  wordSpacing: "15px",
                }}
              >
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Forth Tab*/}
      <div className={styles.forthTab}>
        <h1>Happy Customers</h1>
        <div className={styles.personInfo}>
          <div className={styles.personOne}>
            <img src={person1} alt="" />
            <p>
              “Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts. Separated
              they live in Bookmarksgrove right at the coast of the Semantics, a
              large language ocean.”
            </p>
            <p style={{ marginLeft: "5%", color: "#6c757d" }}>— Clare Gupta</p>
          </div>
          <div className={styles.personTwo}>
            <img src={person2} alt="" />
            <p>
              “Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts. Separated
              they live in Bookmarksgrove right at the coast of the Semantics, a
              large language ocean.”
            </p>
            <p style={{ marginLeft: "5%", color: "#6c757d" }}>— Rogie Slater</p>
          </div>
          <div className={styles.personThree}>
            <img src={person3} alt="" />
            <p>
              “Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts. Separated
              they live in Bookmarksgrove right at the coast of the Semantics, a
              large language ocean.”
            </p>
            <p style={{ marginLeft: "5%", color: "#6c757d" }}>— John Doe</p>
          </div>
        </div>
      </div>

        {/* Fifth Tab */}

      <div className={styles.fifthTab}>
        <div className={styles.topDest}>
          <h1>Top Destination</h1>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. In dolor,
            iusto doloremque quo odio repudiandae sunt eveniet? Enim facilis
            laborum voluptate id porro, culpa maiores quis, blanditiis
            laboriosam alias. Sed.
          </p>
        </div>
        <div className={styles.destImg}>
          <div className={styles.destImg1}>
            <img src={Image6} alt="" />
            <h3>Food & Wines</h3>
            <div className={styles.star}>
              <img src={Star} alt="" />
              <p>3,239 reviews</p>
            </div>
          </div>
          <div className={styles.destImg2}>
            <img src={Image5} alt="" />
            <h3>Resort & Spa</h3>
            <div className={styles.star}>
              <img src={Star} alt="" />
              <p>3,239 reviews</p>
            </div>
          </div>
          <div className={styles.destImg3}>
            <img src={Sofa} alt="" />
            <h3>Hotel Rooms</h3>
            <div className={styles.star}>
              <img src={Star} alt="" />
              <p>3,239 reviews</p>
            </div>
          </div>
          <div className={styles.destImg4}>
            <img src={climb} alt="" />
            <h3>Mountain Climbing</h3>
            <div className={styles.star}>
              <img src={Star} alt="" />
              <p>3,239 reviews</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}

      <div className={styles.footer}>
        <div className={styles.footerItems}>
          <div className={styles.quickLink}>
            <h3>Quick Link</h3>
            <Link to="/" target="_blank" className={styles.links}>
              About Us
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Terms & Conditions
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Privacy Policy
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Help
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Rooms
            </Link>
          </div>
          <div className={styles.support}>
            <h3>Support</h3>
            <Link to="/" target="_blank" className={styles.links}>
              Our Location
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              The Hosts
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              About
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Contact
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Restaurant
            </Link>
          </div>
          <div className={styles.contactInfo}>
            <h3>ContactInfo</h3>
            <p style={{ color: "#fff" }}>Address:</p>
            <p style={{ marginTop: "1px", fontSize: "21px" }}>
              98 West 21th Street, Suite 721{" "}
            </p>
            <p style={{ marginTop: "1px", fontSize: "21px" }}>
              New York NY 10016
            </p>
            <p style={{ marginTop: "6px", color: "#fff" }}>Phone:</p>
            <p style={{ marginTop: "1px" }}>(+1) 435 3533</p>
            <p style={{ color: "#fff", marginTop: "6px" }}>Email:</p>
            <p style={{ marginTop: "1px" }}>info@yourdomain.com</p>
          </div>
          <div className={styles.subscribe}>
            <h3>Subscribe</h3>
            <p>Sign up for our newsletter</p>
            <input type="email" placeholder="Your Email..." />
          </div>
        </div>
        <hr style={{ border: "0.5px solid #5d5d5db7", width: "82%" }} />
        <div className={styles.footerBottom}>
          <p>
            Copyright © 2024 All rights reserved | This template is made with by{" "}
            <Link to="/" target="_blank" className={styles.btmLink}>
              Colorlib
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Home;

import React, { useState, useEffect, useCallback } from "react";
import styles from "./styles/hotel.module.css";
import { Link } from "react-router-dom";
import image from "./images/slider-4.jpg.webp";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import breakfastImage from "./images/breakfast.jpg";
import planetImage from "./images/planetEarth.jpg";
import planeImage from "./images/airplane.jpg";
import Beach from "./images/beach.jpg";
import Mountain from "./images/mountains.jpg";
import Balloons from "./images/hotAirBalloon.jpg";
import welcomeImage from "./images/slider-1.jpg.webp";
import preImage from "./images/slider-2.jpg.webp";
import ImageSlider from "./imageSlider";
import Image6 from "./images/slider-6.jpg.webp";
import Image5 from "./images/slider-5.jpg.webp";
import Sofa from "./images/sofa.jpg";

function Hotels() {
  const [isOpen, setIsOpen] = useState(false);
  const [showHamburger, setShowHamburger] = useState(true);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = useCallback(() => {
    if (isOpen) {
      setIsOpen(false);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleScroll = () => {
      const headerHeight = document.querySelector(
        `.${styles.header}`
      ).offsetHeight;
      if (window.scrollY > headerHeight) {
        setShowHamburger(false);
      } else {
        setShowHamburger(true);
      }
      closeMenu();
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [closeMenu]);

  return (
    <div>
      <div
        className={styles.header}
        style={{ backgroundImage: `url(${image})` }}
      >
        <div className={styles.overlay}></div>
        <div className={styles.content}>
          <h1 className={styles.title}>Hepta</h1>
          <h1 className={styles.heading}>Our Hotel</h1>
          <p className={styles.description}>
            A free template by{" "}
            <Link to="/" target="_blank" className={styles.link}>
              Colorlib
            </Link>
            . Download and share!
          </p>
        </div>
        {showHamburger && (
          <div className={styles.hamburger} onClick={toggleMenu}>
            ☰
          </div>
        )}
        <div className={`${styles.menu} ${isOpen ? styles.open : ""}`}>
          <Link to="/" className={styles.menuItem}>
            Home
          </Link>
          <Link to="/hotels" className={styles.menuItem}>
            Hotels
          </Link>
          <Link to="/aboutUs" className={styles.menuItem}>
            About Us
          </Link>
          <Link to="/gallery" className={styles.menuItem}>
            Gallery
          </Link>
          <Link to="/news" className={styles.menuItem}>
            News
          </Link>
          <Link to="/Contact" className={styles.menuItem}>
            Contact
          </Link>
        </div>
      </div>

      
      {/*Upper Items of Welcome*/}
      <div className={styles.upperItems}>
        <div className={styles.goodFoods}>
          <img src={breakfastImage} alt="" />
          <h2
            style={{
              width: "50%",
              fontFamily: "'Abril Fatface', 'Times', serif",
            }}
          >
            Good Foods
          </h2>
          <p
            style={{
              width: "70%",
              fontSize: "18px",
              textAlign: "center",
              marginLeft: "-80px",
              color: "#6C757D",
            }}
          >
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts.
          </p>
        </div>
        <div className={styles.travelAnyWhere}>
          <img src={planetImage} alt="" />
          <h2
            style={{
              marginRight: "60%",
              fontFamily: "'Abril Fatface', 'Times', serif",
            }}
          >
            Travel Anywhere
          </h2>
          <p
            style={{
              width: "70%",
              fontSize: "18px",
              textAlign: "center",
              marginLeft: "-80px",
              color: "#6C757D",
            }}
          >
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts.
          </p>
        </div>
        <div className={styles.airplane}>
          <img src={planeImage} alt="" />
          <h2
            style={{
              marginLeft: "10%",
              fontFamily: "'Abril Fatface', 'Times', serif",
            }}
          >
            Airplane
          </h2>
          <p
            style={{
              width: "70%",
              fontSize: "18px",
              textAlign: "center",
              marginLeft: "-80px",
              color: "#6C757D",
            }}
          >
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts.
          </p>
        </div>
      </div>

      {/*Lower items of welcome*/}
      <div className={styles.lowerItems}>
        <div className={styles.goodFoods}>
          <img src={Beach} alt="" />
          <h2
            style={{
              width: "50%",
              marginRight: "70%",
              fontSize: "30px",
              fontFamily: "'Abril Fatface', 'Times', serif",
            }}
          >
            Beach Resort
          </h2>
          <p
            style={{
              width: "70%",
              fontSize: "18px",
              textAlign: "center",
              marginLeft: "-80px",
              color: "#6C757D",
            }}
          >
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts.
          </p>
        </div>
        <div className={styles.travelAnyWhere}>
          <img src={Mountain} alt="" />
          <h2
            style={{
              marginLeft: "-2%",
              fontFamily: "'Abril Fatface', 'Times', serif",
            }}
          >
            Mountain Climbing
          </h2>
          <p
            style={{
              width: "70%",
              fontSize: "18px",
              textAlign: "center",
              marginLeft: "-80px",
              color: "#6C757D",
            }}
          >
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts.
          </p>
        </div>
        <div className={styles.airplane}>
          <img src={Balloons} alt="" />
          <h2
            style={{
              marginRight: "70%",
              fontFamily: "'Abril Fatface', 'Times', serif",
            }}
          >
            Hot Air Balloon
          </h2>
          <p
            style={{
              width: "70%",
              fontSize: "18px",
              textAlign: "center",
              marginLeft: "-80px",
              color: "#6C757D",
            }}
          >
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts.
          </p>
        </div>
      </div>

      {/* Family Room */}
      <div id="nextDiv" className={styles.welcomeBody}>
        <div className={styles.imageStyle}>
          <img src={welcomeImage} alt="" />
        </div>
        <div className={styles.welcomeText}>
          <h1> Family Room </h1>
          <p className={styles.farText}>
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts. Separated they
            live in Bookmarksgrove right at the coast of the Semantics, a large
            language ocean.
          </p>
          <p className={styles.farText}>
            A small river named Duden flows by their place and supplies it with
            the necessary regelialia.
          </p>  
            <div>
              <button className={styles.watchBtn}>LEARN MORE</button>
            </div>
        </div>
      </div>

      {/* Presidential Room */ }
      <div id="nextDiv" className={styles.presidentialBody}>
      <div className={styles.presidentialText}>
          <h1> Presidential Room </h1>
          <p className={styles.farTextPre}>
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts. Separated they
            live in Bookmarksgrove right at the coast of the Semantics, a large
            language ocean.
          </p>
          <p className={styles.farTextPre}>
            A small river named Duden flows by their place and supplies it with
            the necessary regelialia.
          </p>  
            <div>
              <button className={styles.watchBtnPre}>LEARN MORE</button>
            </div>
        </div>
        <div className={styles.imageStylePre}>
          <img src={preImage} alt="" />
        </div>
        
      </div>
      <div className={styles.thirdTab}>
        <div className={styles.internationalTour}>
          <h1 style={{ width: "50%", textAlign: "center", fontSize: "110px", marginBottom: "0%" }}>
            Hotel Gallery
          </h1>
        </div>
        <div className={styles.tourPara}>
          <p
            style={{
              width: "50%",
              textAlign: "center",
              fontSize: "25px",
              color: "#6C757D",
            }}
          >
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia, there live the blind texts. Separated they
            live in Bookmarksgrove right at the coast of the Semantics, a large
            language ocean.
          </p>
        </div>
        <div style={{marginTop: "80px", backgroundColor: "#e9ecef"}}>
          <ImageSlider />
        </div>

            {/* More Hotel Features */}
            <div style={{ backgroundColor: "#e9ecef", height: "127vh" }}>
          <div className={styles.blog}>
            <h1>More Hotel Features</h1>
          </div>
          <div className={styles.blogPara}>
            <p>
              Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts. Separated
              they live in Bookmarksgrove right at the coast of the Semantics, a
              large language ocean.
            </p>
          </div>
          <div className={styles.threeImages}>
            <div className={styles.imageSix}>
              <img src={Image6} alt="" />
              <h1>Five Reasons to Stay at Villa Resort</h1>
              
            </div>
            <div className={styles.imageFive}>
              <img src={Image5} alt="" />
              <h1>Five Reasons to Stay at Villa Resort</h1>
              
            </div>
            <div className={styles.imageSofa}>
              <img src={Sofa} alt="" />
              <h1>Five Reasons to Stay at Villa Resort</h1>
             
            </div>
          </div>
        </div>
        </div>

              {/* Footer */}

      <div className={styles.footer}>
        <div className={styles.footerItems}>
          <div className={styles.quickLink}>
            <h3>Quick Link</h3>
            <Link to="/" target="_blank" className={styles.links}>
              About Us
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Terms & Conditions
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Privacy Policy
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Help
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Rooms
            </Link>
          </div>
          <div className={styles.support}>
            <h3>Support</h3>
            <Link to="/" target="_blank" className={styles.links}>
              Our Location
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              The Hosts
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              About
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Contact
            </Link>
            <Link to="/" target="_blank" className={styles.links}>
              Restaurant
            </Link>
          </div>
          <div className={styles.contactInfo}>
            <h3>ContactInfo</h3>
            <p style={{ color: "#fff" }}>Address:</p>
            <p style={{ marginTop: "1px", fontSize: "21px" }}>
              98 West 21th Street, Suite 721{" "}
            </p>
            <p style={{ marginTop: "1px", fontSize: "21px" }}>
              New York NY 10016
            </p>
            <p style={{ marginTop: "6px", color: "#fff" }}>Phone:</p>
            <p style={{ marginTop: "1px" }}>(+1) 435 3533</p>
            <p style={{ color: "#fff", marginTop: "6px" }}>Email:</p>
            <p style={{ marginTop: "1px" }}>info@yourdomain.com</p>
          </div>
          <div className={styles.subscribe}>
            <h3>Subscribe</h3>
            <p>Sign up for our newsletter</p>
            <input type="email" placeholder="Your Email..." />
          </div>
        </div>
        <hr style={{ border: "0.5px solid #5d5d5db7", width: "82%" }} />
        <div className={styles.footerBottom}>
          <p>
            Copyright © 2024 All rights reserved | This template is made with by{" "}
            <Link to="/" target="_blank" className={styles.btmLink}>
              Colorlib
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
export default Hotels;

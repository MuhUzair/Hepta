import React from 'react';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./components/home";
import AboutUs from "./components/aboutUs";
import Contact from "./components/contact";
import Gallery from "./components/gallery";
import Hotels from "./components/hotels";
import News from "./components/news";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/hotels"element={<Hotels/>}/>
        <Route path="/aboutUs"element={<AboutUs/>}/>
        <Route path="/gallery"element={<Gallery/>}/>
        <Route path="/news"element={<News/>}/>
        <Route path="/contact"element={<Contact/>}/>
      </Routes>
    </Router>
  );
}

export default App;
